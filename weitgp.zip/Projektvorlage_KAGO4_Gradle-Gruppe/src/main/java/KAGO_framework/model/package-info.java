/**
 * Created by KNB on 04.12.2017.
 *
 * Dieses Package beinhaltet die Oberklasse für alle Klassen, die zu zeichnende Objekte erzeugen.
 * Dieses Package ist Bestandteil des Framworks und sollte nur mit ausreichendem Wissen geändert werden.
 */
package KAGO_framework.model;