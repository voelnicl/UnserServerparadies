/**
 * Created by KNB on 04.12.2017.
 * Dieses Package beinhaltet die nötigen Klassen für die grafische Repräsentation.
 *
 * Dieses Package ist Bestandteil des Frameworks und sollte nur mit ausreichendem Wissen geändert werden.
 */
package KAGO_framework.view;